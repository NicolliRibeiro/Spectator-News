
  document.addEventListener('DOMContentLoaded', function () {
    const form = document.querySelector('form');
    const cardContainer = document.getElementById('card-container');

    form.addEventListener('submit', function (event) {
      event.preventDefault(); // Evita o envio do formulário

      const alimento = document.getElementById('nalimento').value;
      const descricao = document.getElementById('info').value;
      const imagem = document.getElementById('imagem').value;

      // Cria o card com Bootstrap
      const card = document.createElement('div');
      card.classList.add('col');
      card.innerHTML = `
        <div class="card h-100">
          <img src="${imagem}" class="card-img-top" alt="${alimento}">
          <div class="card-body">
            <h5 class="card-title">${alimento}</h5>
            <p class="card-text">${descricao}</p>
          </div>
          <div class="card-footer">
            <button class="btn btn-danger" onclick="removerCard(this)">Remover</button>
          </div>
        </div>
      `;

      cardContainer.appendChild(card);
      form.reset();
    });

    // Função para remover o card
    window.removerCard = function (button) {
      const card = button.closest('.col');
      card.remove();
    };
  });